<?php


namespace App\Controllers;

use App\Core\AControllerBase;
use App\Models\Article;

class BlogController extends AControllerBase
{

    public function index()
    {
        return Article::getAll();
    }

    public function add(){

        if (!isset($_POST['title'])) return null;

        $art = new Article($_POST['title'], $_POST['text']);
        $art->save();

        $this->redirectToIndex();

    }

    public function delete(){
        if (isset($_GET['id'])) {
            $art = Article::getOne($_GET['id']);
            $art->delete();
        }
        $this->redirectToIndex();
    }

    public function edit(){
        $val = null;
        if (isset($_POST['id'])) {
            $val = $this->validate($_POST['title'],$_POST['text']);

            $art = Article::getOne($_POST['id']);
            $art->setTitle($_POST['title']);
            $art->setText($_POST['text']);

            if ( $val == null) {
                $art->save();
                $this->redirectToIndex();
            }
        } else {
            $art = Article::getOne($_GET['id']);
        }

        return [
            'model' => $art,
            'err' => $val,
        ];
    }

    public function validate($title, $text){

        $titleErrors = [];
        if (strlen($title) < 3) {
            $titleErrors[] = "Nazov je moc kratky (min. 3 chars)";
        }
        if (is_numeric($title[0])) {
            $titleErrors[] = "Nazov nesmie zacinat cislom.";
        }

        $textErrors = [];
        if (strlen($text) < 20) {
            $textErrors[] = "Text je moc kratky (min. 20 chars)";
        }

        return count($titleErrors) > 0 || count($textErrors) > 0 ? [ 'title' => $titleErrors, 'text' => $textErrors] : null;
    }

    public function redirectToIndex()
    {
        header("Location: http://localhost/mvc?c=blog");
        die();
    }
}