<div class="container">
    <h1>Pridanie noveho clanku</h1>
</div>
<?php

include "common/form.view.php";