<?php /** @var Array $data */ ?>
<div class="container">
    <div class="row">
        <div class="col">
            Ahoj <?= $data['meno'] ?>!
        </div>
    </div>
</div>
