<?php

use App\App;

require "ClassLoader.php";

$app = new App();
$app->run();